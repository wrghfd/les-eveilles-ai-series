Variables d’environnement à définir dans n8n / Docker:
- ELEVENLABS_API_KEY
- VIDEO_RENDER_PROXY_URL
- VIDEO_RENDER_PROXY_TOKEN

Hypothèse importante:
- le proxy vidéo reçoit le JSON du plan et renvoie directement un MP4 binaire.
- cela permet de garder n8n simple et stable, même si Runway/Kling fonctionnent en jobs asynchrones.

Fichiers requis:
- /data/series/les_eveilles/serie_youtube_locked_master.json
- dossier de sortie: /data/series/les_eveilles/output

Avant exécution:
- remplacer les voice_id_placeholder dans le JSON maître
- changer selected_episode_id dans le nœud "Init Controls"
- choisir provider_video = RUNWAY ou KLING dans le même nœud