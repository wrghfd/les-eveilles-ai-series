# Video Render Proxy

## Démarrage
```bash
npm install
cp .env.video_proxy.example .env
node --env-file=.env video_render_proxy_server.js
```

## Endpoint
`POST /render-video`

Header requis:
```bash
Authorization: Bearer $VIDEO_RENDER_PROXY_TOKEN
Content-Type: application/json
```

Payload attendu:
```json
{
  "provider": "RUNWAY",
  "episode_id": "E01",
  "scene_id": "S01",
  "shot_id": "SH01",
  "duration_sec": 5,
  "prompt_video": "Lucas walks in Paris street, cinematic realism",
  "prompt_image": "https://your-character-reference-image",
  "output_filename": "E01_S01_SH01.mp4"
}
```

Réponse:
- succès: binaire `video/mp4`
- erreur: JSON

## Notes
- La partie Runway est câblée pour créer une tâche puis la poller jusqu'à récupérer l'URL de sortie.
- La partie Kling est un adaptateur à finir avec les chemins exacts de ton compte/API.
