/**
 * Video Render Proxy for n8n
 * - POST /render-video
 * - Accepts a normalized payload from n8n
 * - Calls Runway directly
 * - Includes a Kling adapter stub you can finish with your exact account endpoint/payload
 *
 * Node 18+
 */

import express from 'express';
import fs from 'fs/promises';
import path from 'path';

const app = express();
app.use(express.json({ limit: '10mb' }));

const PORT = process.env.PORT || 8787;
const VIDEO_RENDER_PROXY_TOKEN = process.env.VIDEO_RENDER_PROXY_TOKEN || '';
const TMP_DIR = process.env.TMP_DIR || '/tmp/video_proxy';

function requireAuth(req, res, next) {
  const auth = req.headers.authorization || '';
  const expected = `Bearer ${VIDEO_RENDER_PROXY_TOKEN}`;
  if (!VIDEO_RENDER_PROXY_TOKEN || auth !== expected) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function ensureDir(p) {
  await fs.mkdir(p, { recursive: true });
}

async function downloadToBuffer(url, headers = {}) {
  const resp = await fetch(url, { headers });
  if (!resp.ok) {
    const text = await resp.text().catch(() => '');
    throw new Error(`Download failed ${resp.status}: ${text}`);
  }
  const ab = await resp.arrayBuffer();
  return Buffer.from(ab);
}

function getProvider(payload) {
  return String(payload.provider || 'RUNWAY').toUpperCase();
}

function buildRunwayHeaders() {
  const apiKey = process.env.RUNWAY_API_KEY;
  if (!apiKey) throw new Error('RUNWAY_API_KEY missing');
  return {
    'Authorization': `Bearer ${apiKey}`,
    'Content-Type': 'application/json',
    'X-Runway-Version': '2024-11-06',
  };
}

/**
 * Runway adapter
 * Expected payload:
 * {
 *   provider: "RUNWAY",
 *   prompt_video: "...",
 *   duration_sec: 5,
 *   ratio: "1280:720", // optional
 *   model: "gen4_turbo", // optional
 *   prompt_image: "https://...", // optional for image-to-video consistency
 *   seed: 12345 // optional
 * }
 */
async function renderWithRunway(payload) {
  const headers = buildRunwayHeaders();
  const model = payload.model || 'gen4_turbo';
  const promptText = payload.prompt_video;
  const duration = Number(payload.duration_sec || 5);

  // Normalize into Runway task request.
  // Text-to-video can omit promptImage.
  const body = {
    model,
    promptText,
    duration,
  };

  if (payload.prompt_image) body.promptImage = payload.prompt_image;
  if (payload.ratio) body.ratio = payload.ratio;
  if (payload.seed !== undefined && payload.seed !== null && payload.seed !== '') body.seed = payload.seed;

  // Create task
  const createResp = await fetch('https://api.dev.runwayml.com/v1/text_to_video', {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
  });

  if (!createResp.ok) {
    const text = await createResp.text().catch(() => '');
    throw new Error(`Runway create task failed ${createResp.status}: ${text}`);
  }

  const task = await createResp.json();
  const taskId = task.id || task.taskId;
  if (!taskId) {
    throw new Error(`Runway task id missing in response: ${JSON.stringify(task)}`);
  }

  // Poll task
  const maxAttempts = Number(process.env.RUNWAY_MAX_ATTEMPTS || 120);
  const pollMs = Number(process.env.RUNWAY_POLL_MS || 5000);

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    const pollResp = await fetch(`https://api.dev.runwayml.com/v1/tasks/${taskId}`, {
      method: 'GET',
      headers,
    });

    if (!pollResp.ok) {
      const text = await pollResp.text().catch(() => '');
      throw new Error(`Runway poll failed ${pollResp.status}: ${text}`);
    }

    const statusData = await pollResp.json();
    const status = String(statusData.status || '').toUpperCase();

    if (status === 'SUCCEEDED') {
      const output = statusData.output || [];
      const first = Array.isArray(output) ? output[0] : output;
      const videoUrl = first?.url || first?.video_url || first;
      if (!videoUrl) {
        throw new Error(`Runway succeeded but no output URL found: ${JSON.stringify(statusData)}`);
      }
      const videoBuffer = await downloadToBuffer(videoUrl);
      return {
        taskId,
        status,
        videoBuffer,
        providerResponse: statusData,
      };
    }

    if (status === 'FAILED' || status === 'CANCELLED') {
      throw new Error(`Runway task ended with status ${status}: ${JSON.stringify(statusData)}`);
    }

    await sleep(pollMs);
  }

  throw new Error('Runway polling timed out');
}

/**
 * Kling adapter stub
 * Official public snippets indicate ongoing API changes and image/video reference support,
 * but exact endpoint/account payload can vary.
 * Fill in KLING_BASE_URL / KLING_CREATE_PATH / KLING_STATUS_PATH and payload mapping for your account.
 */
async function renderWithKling(payload) {
  const apiKey = process.env.KLING_API_KEY;
  const baseUrl = process.env.KLING_BASE_URL;          // e.g. https://...your official endpoint...
  const createPath = process.env.KLING_CREATE_PATH;    // e.g. /v1/videos/text2video or your account path
  const statusPath = process.env.KLING_STATUS_PATH;    // e.g. /v1/videos/tasks/{task_id}
  if (!apiKey || !baseUrl || !createPath || !statusPath) {
    throw new Error('Kling env vars missing: KLING_API_KEY, KLING_BASE_URL, KLING_CREATE_PATH, KLING_STATUS_PATH');
  }

  const headers = {
    'Authorization': `Bearer ${apiKey}`,
    'Content-Type': 'application/json',
  };

  // Adjust this mapping to your exact Kling API/account.
  const createBody = {
    prompt: payload.prompt_video,
    duration: Number(payload.duration_sec || 5),
    image: payload.prompt_image || undefined,
    model: payload.model || undefined,
    seed: payload.seed || undefined,
  };

  const createResp = await fetch(`${baseUrl}${createPath}`, {
    method: 'POST',
    headers,
    body: JSON.stringify(createBody),
  });

  if (!createResp.ok) {
    const text = await createResp.text().catch(() => '');
    throw new Error(`Kling create task failed ${createResp.status}: ${text}`);
  }

  const created = await createResp.json();
  const taskId = created.id || created.task_id || created.data?.task_id;
  if (!taskId) {
    throw new Error(`Kling task id missing in response: ${JSON.stringify(created)}`);
  }

  const maxAttempts = Number(process.env.KLING_MAX_ATTEMPTS || 120);
  const pollMs = Number(process.env.KLING_POLL_MS || 5000);

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    const statusUrl = `${baseUrl}${statusPath.replace('{task_id}', taskId)}`;
    const pollResp = await fetch(statusUrl, { method: 'GET', headers });

    if (!pollResp.ok) {
      const text = await pollResp.text().catch(() => '');
      throw new Error(`Kling poll failed ${pollResp.status}: ${text}`);
    }

    const statusData = await pollResp.json();
    const status = String(
      statusData.status || statusData.task_status || statusData.data?.status || ''
    ).toUpperCase();

    if (['SUCCEEDED', 'SUCCESS', 'COMPLETED'].includes(status)) {
      const videoUrl =
        statusData.video_url ||
        statusData.data?.video_url ||
        statusData.data?.works?.[0]?.resource?.resource ||
        statusData.output?.[0]?.url;

      if (!videoUrl) {
        throw new Error(`Kling succeeded but no output URL found: ${JSON.stringify(statusData)}`);
      }

      const videoBuffer = await downloadToBuffer(videoUrl);
      return {
        taskId,
        status,
        videoBuffer,
        providerResponse: statusData,
      };
    }

    if (['FAILED', 'FAIL', 'ERROR', 'CANCELLED'].includes(status)) {
      throw new Error(`Kling task ended with status ${status}: ${JSON.stringify(statusData)}`);
    }

    await sleep(pollMs);
  }

  throw new Error('Kling polling timed out');
}

app.get('/health', async (_req, res) => {
  res.json({ ok: true });
});

app.post('/render-video', requireAuth, async (req, res) => {
  const payload = req.body || {};
  const provider = getProvider(payload);

  try {
    await ensureDir(TMP_DIR);

    let result;
    if (provider === 'KLING') {
      result = await renderWithKling(payload);
    } else if (provider === 'RUNWAY') {
      result = await renderWithRunway(payload);
    } else {
      return res.status(400).json({ error: `Unsupported provider: ${provider}` });
    }

    const filename = payload.output_filename || `${provider.toLowerCase()}_${Date.now()}.mp4`;

    res.setHeader('Content-Type', 'video/mp4');
    res.setHeader('Content-Disposition', `attachment; filename="${path.basename(filename)}"`);
    res.setHeader('X-Provider', provider);
    res.setHeader('X-Task-Id', result.taskId || '');
    return res.status(200).send(result.videoBuffer);
  } catch (err) {
    return res.status(500).json({
      error: err.message || String(err),
      provider,
    });
  }
});

app.listen(PORT, () => {
  console.log(`Video render proxy listening on :${PORT}`);
});
